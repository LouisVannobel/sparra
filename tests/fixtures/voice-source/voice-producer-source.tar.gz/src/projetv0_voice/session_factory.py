"""Atomic process factory for one owned, measured call session."""

from __future__ import annotations

import asyncio
from collections.abc import Callable, Coroutine
from contextlib import suppress
from importlib.metadata import version
from typing import Any, Protocol, cast
from uuid import UUID

import httpx
from pipecat.processors.frame_processor import FrameProcessor

from projetv0_voice.admission import (
    CallConstructionGrant,
    TerminalAuthority,
    TerminalProposal,
    _TerminalCapability,
)
from projetv0_voice.audio_contract import BeginCallSnapshotV2, VoiceOperationV2
from projetv0_voice.calendar import CalendarSink
from projetv0_voice.config import AgentManifestV1
from projetv0_voice.crypto import CryptoKeyring
from projetv0_voice.metrics import RuntimeMetrics, _CallMetricLease
from projetv0_voice.models import CallUpsertPayloadV1, VoiceOperationV1
from projetv0_voice.persistence.commands import PersistenceCommand
from projetv0_voice.persistence.writer import PersistenceWriter
from projetv0_voice.pipeline import _CallObservers
from projetv0_voice.qualified_profile import RuntimeDeploymentProfileV1
from projetv0_voice.session import (
    CallIdentity,
    CallSession,
    PublicSttHttpClient,
    RecordingBoundary,
    ServiceBundle,
    SessionWriter,
)
from projetv0_voice.telnyx.handshake import AuthenticatedTelnyxHandshake


class ProcessTaskRegistrar(Protocol):
    def try_start(
        self,
        coroutine: Coroutine[object, object, None],
        *,
        name: str,
    ) -> asyncio.Task[None] | None: ...


class _SessionRegistry(Protocol):
    async def consume_claim_for_construction(
        self,
        claim: object,
        stream_id: str,
        owner: object,
        owner_task: asyncio.Task[None],
    ) -> CallConstructionGrant | None: ...

    async def construction_is_live(
        self,
        grant: CallConstructionGrant,
        owner: object,
        owner_task: asyncio.Task[None],
    ) -> bool: ...

    async def activate_session(
        self,
        grant: CallConstructionGrant,
        owner: object,
        owner_task: asyncio.Task[None],
        session: object,
    ) -> bool: ...

    async def reserve_or_read_terminal(
        self,
        grant: CallConstructionGrant,
        capability: _TerminalCapability,
        proposed: TerminalProposal,
    ) -> TerminalAuthority: ...

    async def complete_reserved_terminal(self, authority: object) -> bool: ...

    async def prepare_required_recording_drain(
        self,
        call_id: UUID,
    ) -> TerminalAuthority | None: ...

    def _note_terminal_failure(self, code: str) -> None: ...


class _RegistryTerminalizer:
    __slots__ = ("_capability", "_grant", "_owner", "_registry")

    def __init__(
        self,
        registry: _SessionRegistry,
        grant: CallConstructionGrant,
        owner: _CallLifecycleOwner,
    ) -> None:
        self._registry = registry
        self._grant = grant
        self._owner = owner
        capability = owner._terminal_capability
        if capability is None:
            raise RuntimeError("terminal_capability_unavailable") from None
        self._capability = capability

    async def terminalize(
        self,
        _identity: CallIdentity,
        *,
        status: str,
        reason: str,
    ) -> None:
        del status, reason

    async def reserve_or_read(
        self,
        proposed: TerminalProposal,
    ) -> TerminalAuthority:
        return await self._registry.reserve_or_read_terminal(
            self._grant,
            self._capability,
            proposed,
        )

    def transfer_to_cleanup(self, cleanup_task: asyncio.Task[None]) -> None:
        self._capability.transfer_to_cleanup(cleanup_task)

    async def complete(self, authority: TerminalAuthority) -> bool:
        return await self._registry.complete_reserved_terminal(authority)

    async def request_human(self, *, action_is_current: Callable[[], bool]) -> str:
        return cast(str, await cast(Any, self._registry).request_human(
            self._grant.generation, action_is_current=action_is_current,
        ))

    async def human_tool_available(self) -> bool:
        return cast(
            bool, await cast(Any, self._registry).human_tool_available(self._grant.generation)
        )

    def note_failure(self, code: str) -> None:
        self._registry._note_terminal_failure(code)


class _ConstructionStack:
    __slots__ = ("_callbacks",)

    def __init__(self) -> None:
        self._callbacks: list[Callable[[], Any]] = []

    def push(self, callback: Callable[[], Any]) -> None:
        self._callbacks.append(callback)

    def detach_all(self) -> None:
        self._callbacks.clear()

    def discard(self, callback: Callable[[], Any]) -> None:
        self._callbacks = [retained for retained in self._callbacks if retained is not callback]

    async def aclose(self) -> None:
        while self._callbacks:
            callback = self._callbacks.pop()
            try:
                result = callback()
                if hasattr(result, "__await__"):
                    await result
            except BaseException:
                continue


class _CallLifecycleOwner:
    """One closed-gate owner and retained task for a call's entire lifecycle."""

    __slots__ = (
        "_closed",
        "_drain_cause",
        "_factory",
        "_gate",
        "_grant",
        "_handshake",
        "_metric_lease",
        "_phase",
        "_session",
        "_task",
        "_terminal_capability",
    )

    def __init__(self, factory: ProcessSessionFactory) -> None:
        self._factory = factory
        self._closed = asyncio.Event()
        self._gate = asyncio.Event()
        self._phase = "gated"
        self._task: asyncio.Task[None] | None = None
        self._grant: CallConstructionGrant | None = None
        self._handshake: AuthenticatedTelnyxHandshake | None = None
        self._metric_lease: _CallMetricLease | None = None
        self._session: object | None = None
        self._terminal_capability: _TerminalCapability | None = None
        self._drain_cause: str | None = None

    def bind_task(self, task: asyncio.Task[None]) -> None:
        self._task = task

    def publish(
        self,
        grant: CallConstructionGrant,
        handshake: AuthenticatedTelnyxHandshake,
        metric_lease: _CallMetricLease,
    ) -> None:
        self._grant = grant
        self._handshake = handshake
        self._metric_lease = metric_lease
        self._gate.set()

    def request_drain(self, cause: str) -> None:
        if type(cause) is not str or not cause or self._phase == "done":
            return
        if self._drain_cause is None or cause == "recording_required_error":
            self._drain_cause = cause
        session = self._session
        if isinstance(session, CallSession):
            session._latch_drain_reason(cause)  # noqa: SLF001
        task = self._task
        if (
            task is not None
            and task is not asyncio.current_task()
            and not task.done()
            and task.cancelling() == 0
        ):
            task.cancel()

    async def wait(self) -> None:
        wait_task = asyncio.create_task(self._closed.wait())
        cancellation: asyncio.CancelledError | None = None
        while not wait_task.done():
            try:
                await asyncio.shield(wait_task)
            except asyncio.CancelledError as error:
                if cancellation is None:
                    cancellation = error
        await wait_task
        if cancellation is not None:
            raise cancellation

    async def cancel_and_join(self) -> None:
        task = self._task
        if task is None:
            self._phase = "done"
            self._closed.set()
            return
        if not task.done() and task.cancelling() == 0:
            task.cancel()
        while not task.done():
            try:
                await asyncio.shield(task)
            except asyncio.CancelledError:
                continue
            except BaseException:
                break
        if task.done():
            with suppress(BaseException):
                task.result()

    async def run(self) -> None:
        try:
            await self._gate.wait()
            grant = self._grant
            handshake = self._handshake
            metric_lease = self._metric_lease
            task = self._task
            if grant is None or handshake is None or metric_lease is None or task is None:
                return
            self._phase = "constructing"
            await self._factory._construct_and_run(  # noqa: SLF001
                self,
                task,
                grant,
                handshake,
                metric_lease,
            )
        except BaseException:
            return
        finally:
            self._grant = None
            self._handshake = None
            self._session = None
            self._terminal_capability = None
            self._phase = "done"
            self._closed.set()


class ProcessSessionFactory:
    """Create and supervise one exact call from an authenticated handshake."""

    def __init__(
        self,
        *,
        registry: _SessionRegistry,
        registrar: ProcessTaskRegistrar,
        runtime_metrics: RuntimeMetrics,
        manifest: AgentManifestV1,
        profile: RuntimeDeploymentProfileV1,
        writer: SessionWriter,
        keyring: CryptoKeyring,
        stt_http_client_factory: Callable[[], PublicSttHttpClient],
        stt_factory: Callable[[PublicSttHttpClient], FrameProcessor],
        llm_factory: Callable[[], FrameProcessor],
        tts_factory: Callable[[], FrameProcessor],
        recording_factory: Callable[[CallIdentity], RecordingBoundary],
        recording_call_control_identity: object | None = None,
        calendar_sink: CalendarSink | None = None,
        idle_timeout_seconds: float,
        session_factory: Callable[..., CallSession] = CallSession,
        cleanup_phase_timeout_seconds: float = 5.0,
    ) -> None:
        self._calendar_sink = calendar_sink
        self._registry = registry
        self._registrar = registrar
        self._runtime_metrics = runtime_metrics
        self._manifest = manifest
        self._profile = profile
        self._writer = writer
        self._keyring = keyring
        self._stt_http_client_factory = stt_http_client_factory
        self._stt_factory = stt_factory
        self._llm_factory = llm_factory
        self._tts_factory = tts_factory
        self._recording_factory = recording_factory
        self._recording_call_control_identity = recording_call_control_identity
        self._session_factory = session_factory
        self._idle_timeout_seconds = idle_timeout_seconds
        self._cleanup_phase_timeout_seconds = cleanup_phase_timeout_seconds

    @property
    def recording_call_control_identity(self) -> object | None:
        """Expose the recording facade identity fixed by process composition."""

        return self._recording_call_control_identity

    async def run(self, handshake: AuthenticatedTelnyxHandshake) -> None:
        owner = _CallLifecycleOwner(self)
        owner_coroutine = owner.run()
        self._runtime_metrics.record_ws_setup("owner_registration", "waiting")
        try:
            owner_task = self._registrar.try_start(
                owner_coroutine,
                name="voice-call-session-owner",
            )
        except asyncio.CancelledError:
            self._runtime_metrics.record_ws_setup("owner_registration", "cancelled")
            raise
        except Exception:
            self._runtime_metrics.record_ws_setup("owner_registration", "error")
            raise
        if owner_task is None:
            self._runtime_metrics.record_ws_setup("owner_registration", "refused")
            owner._phase = "done"  # noqa: SLF001
            owner._closed.set()  # noqa: SLF001
            raise RuntimeError("session_owner_registration_failed") from None
        self._runtime_metrics.record_ws_setup("owner_registration", "registered")
        owner.bind_task(owner_task)
        self._runtime_metrics.record_ws_setup("construction_grant", "waiting")
        try:
            stream_id = handshake.call_data.stream_id
            grant = await self._registry.consume_claim_for_construction(
                handshake.lease_claim,
                stream_id if type(stream_id) is str else "",
                owner,
                owner_task,
            )
        except BaseException as error:
            self._runtime_metrics.record_ws_setup(
                "construction_grant",
                "cancelled" if isinstance(error, asyncio.CancelledError) else "error",
            )
            await owner.cancel_and_join()
            raise
        if grant is None:
            self._runtime_metrics.record_ws_setup("construction_grant", "refused")
            await owner.cancel_and_join()
            raise RuntimeError("process_lease_claim_unavailable") from None
        self._runtime_metrics.record_ws_setup("construction_grant", "granted")
        metric_lease = self._runtime_metrics.begin_call()
        self._runtime_metrics.record_ws_setup("begin_call", "reached")
        owner.publish(grant, handshake, metric_lease)
        cancellation: asyncio.CancelledError | None = None
        owner_wait = asyncio.create_task(owner.wait())
        while not owner_wait.done():
            try:
                await asyncio.shield(owner_wait)
            except asyncio.CancelledError as error:
                if cancellation is None:
                    cancellation = error
                    owner.request_drain("external_cancel")
            except BaseException:
                break
        try:
            await owner_wait
        except asyncio.CancelledError as error:
            if cancellation is None:
                cancellation = error
        if owner_task.done():
            with suppress(BaseException):
                owner_task.result()
        if cancellation is not None:
            raise cancellation

    async def drain_call_by_id(self, call_id: UUID, reason: str) -> None:
        if type(reason) is not str or reason != "recording_required_error":
            raise ValueError("call_drain_reason_invalid") from None
        if type(call_id) is not UUID:
            raise ValueError("call_drain_call_id_invalid") from None
        authority = await self._registry.prepare_required_recording_drain(call_id)
        if authority is None:
            return
        persisted, cancellation = await self._persist_unconsumed_terminal(authority)
        if not persisted:
            if cancellation is not None:
                raise cancellation
            return
        try:
            await self._registry.complete_reserved_terminal(authority)
        except asyncio.CancelledError as error:
            if cancellation is None:
                cancellation = error
        except BaseException:
            if cancellation is not None:
                raise cancellation from None
            raise
        if cancellation is not None:
            raise cancellation

    async def erase_call_by_id(self, call_id: UUID) -> None:
        await cast(Any, self._registry).stop_call_content(call_id)

    async def stop_call_content_by_id(self, call_id: UUID) -> None:
        await cast(Any, self._registry).stop_call_content(call_id, delete_content=False)

    async def _live(
        self,
        grant: CallConstructionGrant,
        owner: _CallLifecycleOwner,
        owner_task: asyncio.Task[None],
    ) -> bool:
        live = await self._registry.construction_is_live(
            grant,
            owner,
            owner_task,
        )
        if not live and owner._drain_cause is None:  # noqa: SLF001
            owner._drain_cause = "token_deadline"  # noqa: SLF001
        if not live:
            self._runtime_metrics.record_ws_setup("construction", "not_live")
        return live

    async def _construct_and_run(
        self,
        owner: _CallLifecycleOwner,
        owner_task: asyncio.Task[None],
        grant: CallConstructionGrant,
        handshake: AuthenticatedTelnyxHandshake,
        metric_lease: _CallMetricLease,
    ) -> None:
        stack = _ConstructionStack()
        transferred = False
        session: CallSession | None = None
        setup_stage: str | None = "construction"
        self._runtime_metrics.record_ws_setup("construction", "waiting")
        try:
            if not await self._live(grant, owner, owner_task):
                return
            identity = CallIdentity(
                call_id=grant.call_id,
                generation=grant.generation,
                lease_claim=grant.lease_claim,
                deployment_id=grant.deployment_id,
                telnyx_call_control_id=grant.telnyx_call_control_id,
                telnyx_call_leg_id=grant.telnyx_call_leg_id,
                telnyx_call_session_id=grant.telnyx_call_session_id,
                stream_id=grant.stream_id,
                started_at=grant.started_at,
                retention_until=grant.retention_until,
                routing=grant.routing,
                begin_snapshot=grant.begin_snapshot,
                budget_permit=grant.budget_permit,
                original_deadline=grant.original_deadline,
                paid_work_permitted=grant.paid_work_permitted,
            )
            if not await self._live(grant, owner, owner_task):
                return
            stt_client = self._stt_http_client_factory()
            stt_client_close = stt_client.aclose
            stack.push(stt_client_close)
            if grant.paid_work_permitted is not None:
                async def guard_paid_request(_request: httpx.Request) -> None:
                    if not grant.paid_work_permitted or not grant.paid_work_permitted():
                        raise RuntimeError("owned_budget_paid_fence")
                if not isinstance(stt_client, httpx.AsyncClient):
                    raise RuntimeError("owned_budget_stt_client_invalid")
                stt_client.event_hooks["request"].append(guard_paid_request)
            if not await self._live(grant, owner, owner_task):
                return
            stt = self._stt_factory(stt_client)
            stack.push(stt.cleanup)
            if not await self._live(grant, owner, owner_task):
                return
            llm = self._llm_factory()
            if grant.paid_work_permitted is not None:
                cast(Any, llm).paid_work_permitted = grant.paid_work_permitted

            def llm_client_close() -> Any:
                return self._close_llm_client(llm)

            stack.push(llm_client_close)
            stack.push(llm.cleanup)
            if not await self._live(grant, owner, owner_task):
                return
            tts = self._tts_factory()
            if grant.paid_work_permitted is not None:
                cast(Any, tts).paid_work_permitted = grant.paid_work_permitted
            stack.push(tts.cleanup)
            if not await self._live(grant, owner, owner_task):
                return
            services = ServiceBundle(
                stt=stt,
                llm=llm,
                tts=tts,
                stt_http_client=stt_client,
            )
            stack.discard(stt_client_close)
            stack.discard(llm_client_close)
            stack.push(services.aclose)
            if not await self._live(grant, owner, owner_task):
                return
            observers = _CallObservers(
                runtime_metrics=self._runtime_metrics,
                stt=stt,
                llm=llm,
                tts=tts,
            )
            if not await self._live(grant, owner, owner_task):
                return
            recording = self._recording_factory(identity)
            stack.push(
                lambda: recording.cleanup(
                    identity,
                    recording_may_be_active=False,
                    reason="session_construction_failed",
                )
            )
            if not await self._live(grant, owner, owner_task):
                return
            terminalizer = _RegistryTerminalizer(
                self._registry,
                grant,
                owner,
            )
            session = self._session_factory(
                identity=identity,
                manifest=self._manifest,
                profile=self._profile,
                services=services,
                writer=self._writer,
                keyring=self._keyring,
                recording=recording,
                lease_terminalizer=terminalizer,
                registry_terminalizer=terminalizer,
                calendar_sink=self._calendar_sink,
                metric_lease=metric_lease,
                runtime_metrics=self._runtime_metrics,
                observers=observers,
                idle_timeout_seconds=self._idle_timeout_seconds,
                cleanup_phase_timeout_seconds=self._cleanup_phase_timeout_seconds,
            )
            self._runtime_metrics.record_ws_setup("construction", "constructed")
            owner._session = session  # noqa: SLF001
            owner._phase = "preactivated"  # noqa: SLF001
            stack.detach_all()
            transferred = True
            setup_stage = "activation"
            self._runtime_metrics.record_ws_setup("activation", "waiting")
            if await self._registry.activate_session(
                grant,
                owner,
                owner_task,
                session,
            ):
                self._runtime_metrics.record_ws_setup("activation", "activated")
                setup_stage = None
                await session.run(handshake)
                owner._phase = "finishing"  # noqa: SLF001
                return
            self._runtime_metrics.record_ws_setup("activation", "refused")
            if owner._drain_cause is None:  # noqa: SLF001
                owner._drain_cause = "token_deadline"  # noqa: SLF001
        except asyncio.CancelledError:
            if setup_stage is not None:
                self._runtime_metrics.record_ws_setup(setup_stage, "cancelled")
            raise
        except Exception:
            if setup_stage is not None:
                self._runtime_metrics.record_ws_setup(setup_stage, "error")
            raise
        finally:
            if not transferred:
                await stack.aclose()
                await self._finish_unstarted(
                    grant,
                    owner,
                    metric_lease,
                    self._pre_run_reason(owner),
                )
            elif owner._phase == "preactivated" and session is not None:  # noqa: SLF001
                owner._phase = "finishing"  # noqa: SLF001
                try:
                    await session.request_drain(self._pre_run_reason(owner))
                finally:
                    await session.aclose_unstarted()

    @staticmethod
    async def _close_llm_client(llm: FrameProcessor) -> None:
        if version("pipecat-ai") != "1.12.0":
            return
        client = getattr(llm, "_client", None)
        close = getattr(client, "close", None)
        if not callable(close):
            return
        result = close()
        if hasattr(result, "__await__"):
            await result

    @staticmethod
    def _pre_run_reason(owner: _CallLifecycleOwner) -> str:
        return owner._drain_cause or "session_construction_failed"

    async def _finish_unstarted(
        self,
        grant: CallConstructionGrant,
        owner: _CallLifecycleOwner,
        metric_lease: _CallMetricLease,
        reason: str,
    ) -> None:
        owner._phase = "finishing"  # noqa: SLF001
        if reason == "recording_required_error":
            proposed = TerminalProposal(
                status="failed",
                reason=reason,
                metric_class="failed",
                cleanup_hangup=False,
            )
        elif reason == "process_draining":
            proposed = TerminalProposal(
                status="closed",
                reason=reason,
                metric_class="drained",
                cleanup_hangup=True,
            )
        else:
            proposed = TerminalProposal(
                status="failed",
                reason=reason,
                metric_class="failed",
                cleanup_hangup=True,
            )
        terminalizer = _RegistryTerminalizer(self._registry, grant, owner)
        authority = await terminalizer.reserve_or_read(proposed)
        metric_lease.finish(authority.metric_class)
        await self._persist_terminal_call(grant, authority)
        await terminalizer.complete(authority)

    async def _persist_terminal_call(
        self,
        grant: CallConstructionGrant,
        authority: TerminalAuthority,
    ) -> None:
        read_facts = getattr(self._writer, "read_call_lifecycle", None)
        facts = await read_facts(grant.call_id) if callable(read_facts) else None
        local_v2 = (
            isinstance(self._writer, PersistenceWriter) and self._writer.contract_version == 2
        )
        if local_v2 and not isinstance(grant.begin_snapshot, BeginCallSnapshotV2):
            return
        payload = CallUpsertPayloadV1(
                telnyx_call_control_id=grant.telnyx_call_control_id,
                telnyx_call_leg_id=grant.telnyx_call_leg_id,
                telnyx_call_session_id=grant.telnyx_call_session_id,
                status=authority.status,
                disclosure_state="completed"
                if facts is not None
                and facts.disclosure_evidence is not None
                and facts.disclosure_evidence.completed_at is not None
                else "failed",
                started_at=grant.started_at,
                ended_at=None if authority.status == "closing" else authority._closed_at,  # noqa: SLF001
                end_reason=authority.reason,
                retention_until=grant.retention_until,
                **(
                    cast(
                        Any,
                        (
                            {"disclosure_evidence": facts.disclosure_evidence}
                            if facts is not None and facts.disclosure_evidence is not None
                            else {}
                        ),
                    )
                ),
        )
        operation: VoiceOperationV1 | VoiceOperationV2
        if local_v2:
            operation = VoiceOperationV2(schema_version=2, operation_id=authority.completion_token,
                deployment_id=grant.deployment_id, call_id=grant.call_id,
                occurred_at=authority._closed_at, kind="call.upsert", payload=payload)
        else:
            operation = VoiceOperationV1(schema_version=1, operation_id=authority.completion_token,
                deployment_id=grant.deployment_id, call_id=grant.call_id,
                occurred_at=authority._closed_at, kind="call.upsert", payload=payload)
        while True:
            try:
                if isinstance(operation, VoiceOperationV2):
                    if not isinstance(self._writer, PersistenceWriter):
                        raise RuntimeError("terminal_persistence_failed")
                    await self._writer.freeze_call_publication_v2(operation, None,
                        generation=grant.generation.generation, provider_callback=None)
                else:
                    await self._writer.commit_control(
                        PersistenceCommand("outbox", {"operation": operation}, None)
                    )
            except asyncio.CancelledError:
                continue
            except BaseException:
                self._registry._note_terminal_failure("terminal_persistence_failed")
                return
            return

    async def _persist_unconsumed_terminal(
        self,
        authority: TerminalAuthority,
    ) -> tuple[bool, asyncio.CancelledError | None]:
        entry = authority._entry  # noqa: SLF001
        read_facts = getattr(self._writer, "read_call_lifecycle", None)
        facts = await read_facts(entry.call_id) if callable(read_facts) else None
        started_at = entry.claimed_at or entry.answered_at
        if facts is not None:
            started_at = facts.started_at or started_at
        local_v2 = (
            isinstance(self._writer, PersistenceWriter) and self._writer.contract_version == 2
        )
        if local_v2 and not isinstance(entry.begin_snapshot, BeginCallSnapshotV2):
            return True, None
        payload = CallUpsertPayloadV1(
                telnyx_call_control_id=entry.call_control_id,
                telnyx_call_leg_id=entry.call_leg_id,
                telnyx_call_session_id=entry.call_session_id,
                status="failed"
                if authority.status == "closed" and started_at is None
                else authority.status,
                disclosure_state="completed"
                if facts is not None
                and facts.disclosure_evidence is not None
                and facts.disclosure_evidence.completed_at is not None
                else "failed",
                started_at=started_at,
                ended_at=None if authority.status == "closing" else authority._closed_at,  # noqa: SLF001
                end_reason=authority.reason,
                retention_until=entry.initiated_at + self._registry._retention_delta,  # type: ignore[attr-defined]  # noqa: SLF001
                **(
                    cast(
                        Any,
                        (
                            {"disclosure_evidence": facts.disclosure_evidence}
                            if facts is not None and facts.disclosure_evidence is not None
                            else {}
                        ),
                    )
                ),
        )
        operation: VoiceOperationV1 | VoiceOperationV2
        if local_v2:
            operation = VoiceOperationV2(schema_version=2, operation_id=authority.completion_token,
                deployment_id=self._registry._deployment_id,  # type: ignore[attr-defined]  # noqa: SLF001
                call_id=entry.call_id, occurred_at=authority._closed_at,
                kind="call.upsert", payload=payload)
        else:
            operation = VoiceOperationV1(schema_version=1, operation_id=authority.completion_token,
                deployment_id=self._registry._deployment_id,  # type: ignore[attr-defined]  # noqa: SLF001
                call_id=entry.call_id, occurred_at=authority._closed_at,
                kind="call.upsert", payload=payload)
        cancellation: asyncio.CancelledError | None = None
        while True:
            try:
                if isinstance(operation, VoiceOperationV2):
                    if not isinstance(self._writer, PersistenceWriter):
                        raise RuntimeError("terminal_persistence_failed")
                    await self._writer.freeze_call_publication_v2(operation, None,
                        generation=authority._generation, provider_callback=None)
                else:
                    await self._writer.commit_control(
                        PersistenceCommand("outbox", {"operation": operation}, None)
                    )
            except asyncio.CancelledError as error:
                if cancellation is None:
                    cancellation = error
                continue
            except BaseException:
                self._registry._note_terminal_failure("terminal_persistence_failed")
                return False, cancellation
            return True, cancellation


__all__ = ["ProcessSessionFactory", "ProcessTaskRegistrar"]
