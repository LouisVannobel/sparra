"""Explicit operator enrollment/suspension. Runtime startup never calls this module."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import os
import time
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath

from projetv0_voice.persistence.writer import PersistenceWriter
from projetv0_voice.production_wiring import _budget_factory, build_production_factories
from projetv0_voice.qualified_profile import (
    QualifiedDeploymentProfileV1,
    canonical_qualified_profile_sha256,
)
from projetv0_voice.runtime_config import capture_runtime_environment, parse_runtime_settings

_WRITER_CLOSE_SECONDS = 5.0


class OwnedPilotBudgetOutcomeUnknown(RuntimeError):
    """A submitted transition may have committed; never report it as non-commit."""

    def __init__(self) -> None:
        super().__init__("owned_budget_transition_unknown")


async def _close_operator_writer(writer: PersistenceWriter, owner: asyncio.Task[None]) -> None:
    failed = False
    try:
        # Degradation does not stop the owner loop. Drain still queues shutdown
        # behind the in-flight transition and retains any late committed row.
        await writer.drain(_WRITER_CLOSE_SECONDS)
    except BaseException:
        failed = True
        owner.cancel()
    done, _ = await asyncio.wait({owner}, timeout=_WRITER_CLOSE_SECONDS)
    if owner not in done:
        # Like the runtime's hard-exit boundary, an uncloseable native SQLite
        # owner cannot be left running after this standalone operator returns.
        print("owned_budget_transition_unknown", flush=True)
        os._exit(1)
    await owner
    if failed:
        raise RuntimeError("owned_budget_writer_close_failed") from None


async def operate(action: str, *, predecessor_retired: bool,
                  expected_policy_sha256: str | None = None,
                  predecessor_qualified_profile_path: str | None = None,
                  predecessor_image_digest: str | None = None) -> bool:
    if action == "rebind-release" and (
        not predecessor_retired or expected_policy_sha256 is None
        or len(expected_policy_sha256) != 64
        or any(c not in "0123456789abcdef" for c in expected_policy_sha256)
        or predecessor_qualified_profile_path is None
        or not (PurePosixPath(predecessor_qualified_profile_path).is_absolute()
                or Path(predecessor_qualified_profile_path).is_absolute())
        or not predecessor_image_digest
    ):
        return False
    settings = parse_runtime_settings(capture_runtime_environment(os.environ))
    if settings.runtime_mode != "strict":
        raise RuntimeError("owned_budget_operator_refused")
    factories = build_production_factories(settings)
    factories.validate_artifacts(settings)
    manifest = factories.load_manifest(settings)
    selection = factories.load_profile(settings, manifest, datetime.now(UTC))
    if manifest.sparra is None or not isinstance(selection.profile, QualifiedDeploymentProfileV1):
        raise RuntimeError("owned_budget_operator_refused")
    if (action in {"extend-seventh-call", "enable-budgeted-calls", "rebind-release"}
            and manifest.sparra.operation_contract_version != 2):
        raise RuntimeError("owned_budget_operator_refused")
    predecessor_profile_sha256 = None
    if action == "rebind-release":
        assert predecessor_qualified_profile_path is not None
        assert predecessor_image_digest is not None
        predecessor_settings = replace(
            settings,
            qualified_profile_path=PurePosixPath(Path(predecessor_qualified_profile_path).as_posix()),
            image_digest=predecessor_image_digest,
        )
        predecessor_factories = build_production_factories(predecessor_settings)
        predecessor_factories.validate_artifacts(predecessor_settings)
        predecessor_manifest = predecessor_factories.load_manifest(predecessor_settings)
        previous = predecessor_factories.load_profile(
            predecessor_settings, predecessor_manifest, datetime.now(UTC))
        if not isinstance(previous.profile, QualifiedDeploymentProfileV1):
            raise RuntimeError("owned_budget_operator_refused")
        predecessor_profile_sha256 = canonical_qualified_profile_sha256(previous.profile)
    keyring = factories.load_keyring(settings)
    writer = PersistenceWriter(
        Path(str(settings.sqlite_path)),
        keyring,
        contract_version=manifest.sparra.operation_contract_version,
        process_agent_id=manifest.agent_id,
        process_deployment_id=settings.deployment_id,
        release_rebind_only=action == "rebind-release",
    )
    or_key = factories.read_secret(settings.openrouter_api_key_file)
    tel_key = factories.read_secret(settings.telnyx_api_key_file)
    gate = _budget_factory(
        settings, writer, or_key, tel_key, lambda: datetime.now(UTC), time.monotonic
    )
    p = gate.policy
    if (
        p.qualified_profile_sha256 != canonical_qualified_profile_sha256(selection.profile)
        or p.runtime_contract_sha256 != settings.runtime_contract_sha256
        or p.agent_bundle_sha256 != settings.agent_bundle_sha256
        or p.inference_profile_sha256 != settings.inference_profile_sha256
        or p.image_digest != settings.image_digest
        or p.deployment_id != settings.deployment_id
        or p.identity.did != manifest.dids[0]
        or p.identity.connection_id != manifest.sparra.connection_id
        or p.identity.openrouter_credential_sha256
        != hashlib.sha256(or_key.get_secret_value().encode()).hexdigest()
        or p.identity.telnyx_credential_sha256
        != hashlib.sha256(tel_key.get_secret_value().encode()).hexdigest()
    ):
        raise RuntimeError("owned_budget_operator_refused")
    owner = asyncio.create_task(writer.run())
    submitted = False
    try:
        if not await writer.wait_ready():
            if action == "rebind-release":
                # The refusal event precedes connection close; join startup cleanup
                # before asking the unchanged shutdown path to drain a closed owner.
                await asyncio.wait({owner}, timeout=_WRITER_CLOSE_SECONDS)
            return False
        if action == "suspend-restored":
            submitted = True
            return await writer.owned_budget_request("suspend") is True
        if (action not in {"enroll", "extend-sixth-call", "extend-seventh-call",
                           "enable-budgeted-calls", "rebind-release"}
                or not predecessor_retired):
            return False
        if action in {"extend-sixth-call", "extend-seventh-call", "enable-budgeted-calls",
                      "rebind-release"} and (
            expected_policy_sha256 is None or len(expected_policy_sha256) != 64
            or any(c not in "0123456789abcdef" for c in expected_policy_sha256)
        ):
            return False
        fact = await gate.collect()
        submitted = True
        if action == "rebind-release":
            return await writer.owned_budget_request(
                action, observation=fact, predecessor_retired=True,
                expected_policy_sha256=expected_policy_sha256,
                predecessor_qualified_profile_sha256=predecessor_profile_sha256,
                predecessor_image_digest=predecessor_image_digest,
            ) is True
        return (
            await writer.owned_budget_request(
                action, observation=fact, predecessor_retired=True,
                expected_policy_sha256=expected_policy_sha256,
            )
            is True
        )
    except Exception:
        if submitted:
            raise OwnedPilotBudgetOutcomeUnknown() from None
        raise
    finally:
        cleanup = asyncio.create_task(_close_operator_writer(writer, owner))
        cancellation: asyncio.CancelledError | None = None
        while not cleanup.done():
            try:
                await asyncio.shield(cleanup)
            except asyncio.CancelledError as error:
                cancellation = error
            except Exception:
                break
        try:
            cleanup.result()
        except Exception:
            if submitted:
                raise OwnedPilotBudgetOutcomeUnknown() from None
            raise RuntimeError("owned_budget_writer_close_failed") from None
        if cancellation is not None:
            raise cancellation


def main() -> int:
    parser = argparse.ArgumentParser(description="Original Sparra budget operator transition")
    parser.add_argument("action", choices=(
        "enroll", "suspend-restored", "extend-sixth-call", "extend-seventh-call",
        "enable-budgeted-calls", "rebind-release",
    ))
    parser.add_argument("--expected-policy-sha256")
    parser.add_argument("--predecessor-qualified-profile-path")
    parser.add_argument("--predecessor-image-digest")
    parser.add_argument(
        "--predecessor-retired",
        action="store_true",
        help="Confirm predecessor is fenced and prior exposure is settled",
    )
    args = parser.parse_args()
    if (args.action in {"enroll", "extend-sixth-call", "extend-seventh-call",
                       "enable-budgeted-calls", "rebind-release"}
            and not args.predecessor_retired):
        parser.error(f"{args.action} requires --predecessor-retired")
    if args.action in {"extend-sixth-call", "extend-seventh-call", "enable-budgeted-calls",
                       "rebind-release"} and (
        args.expected_policy_sha256 is None or len(args.expected_policy_sha256) != 64
        or any(c not in "0123456789abcdef" for c in args.expected_policy_sha256)
    ):
        parser.error(f"{args.action} requires --expected-policy-sha256 (64 lowercase hex)")
    if args.action == "rebind-release":
        if (not args.predecessor_qualified_profile_path
                or not (PurePosixPath(args.predecessor_qualified_profile_path).is_absolute()
                        or Path(args.predecessor_qualified_profile_path).is_absolute())):
            parser.error("rebind-release requires --predecessor-qualified-profile-path (absolute)")
        if not args.predecessor_image_digest:
            parser.error("rebind-release requires --predecessor-image-digest")
    try:
        if args.action == "rebind-release":
            accepted = asyncio.run(operate(
                args.action, predecessor_retired=args.predecessor_retired,
                expected_policy_sha256=args.expected_policy_sha256,
                predecessor_qualified_profile_path=args.predecessor_qualified_profile_path,
                predecessor_image_digest=args.predecessor_image_digest,
            ))
        else:
            accepted = asyncio.run(operate(
                args.action, predecessor_retired=args.predecessor_retired,
                expected_policy_sha256=args.expected_policy_sha256,
            ))
    except OwnedPilotBudgetOutcomeUnknown:
        print("owned_budget_transition_unknown")
        return 1
    except Exception:
        accepted = False
    print("owned_budget_transition_accepted" if accepted else "owned_budget_transition_refused")
    return 0 if accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
