"""Thin, upstream-first Telnyx serializer extension."""

from __future__ import annotations

import hmac
import json
import re
from collections.abc import Callable
from datetime import datetime
from typing import Any

from pipecat.frames.frames import (
    Frame,
    InputAudioRawFrame,
    InputDTMFFrame,
    InputTransportMessageFrame,
    OutputTransportMessageFrame,
    OutputTransportMessageUrgentFrame,
)
from pipecat.serializers.telnyx import TelnyxFrameSerializer

from projetv0_voice.telnyx.frames import (
    MAX_MARK_NAME_BYTES,
    TelnyxInputDTMFFrame,
    TelnyxMarkFrame,
    TelnyxSerializerError,
    bounded_utf8_text,
)

MAX_WEBSOCKET_MESSAGE_BYTES = 524_288
MAX_EXTENSION_MESSAGE_BYTES = 65_536
MAX_STREAM_ID_BYTES = 1_024
MAX_CALL_CONTROL_ID_BYTES = 1_024
MAX_ERROR_FIELD_BYTES = 256
MAX_ERROR_CODE = 2_147_483_647
MAX_DTMF_TIMESTAMP_BYTES = 32
MAX_DTMF_SEQUENCE_DIGITS = 16
MAX_DTMF_SEQUENCE = 9_007_199_254_740_991
_DTMF_UTC_TIMESTAMP = re.compile(
    r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?Z"
)


class _InvalidJson(ValueError):
    pass


class AudioAdmissionError(RuntimeError):
    """A constant-safe audio-admission contract error."""


class AudioAdmission:
    """A closed-by-default reference bound once to a synchronous predicate."""

    def __init__(self) -> None:
        self._predicate: Callable[[], bool] | None = None

    @property
    def is_bound(self) -> bool:
        return self._predicate is not None

    def bind(self, predicate: Callable[[], bool]) -> None:
        if self._predicate is not None:
            raise AudioAdmissionError("audio_admission_already_bound")
        if not callable(predicate):
            raise AudioAdmissionError("audio_admission_invalid")
        self._predicate = predicate

    def allows_audio(self) -> bool:
        predicate = self._predicate
        if predicate is None:
            return False
        try:
            return predicate() is True
        except Exception:
            raise AudioAdmissionError("audio_admission_failed") from None


def _reject_constant(_value: str) -> None:
    raise _InvalidJson


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise _InvalidJson
        result[key] = value
    return result


def _load_json(
    data: str | bytes,
    *,
    maximum_bytes: int,
    object_pairs_hook: Callable[[list[tuple[str, Any]]], dict[str, Any]] | None = None,
) -> object:
    parsed: object | None = None
    invalid = False
    try:
        raw_bytes = data.encode("utf-8") if isinstance(data, str) else data
        if len(raw_bytes) > maximum_bytes:
            invalid = True
        else:
            parsed = json.loads(
                data,
                object_pairs_hook=object_pairs_hook,
                parse_constant=_reject_constant,
            )
    except (UnicodeEncodeError, UnicodeDecodeError, json.JSONDecodeError, _InvalidJson):
        invalid = True
    if invalid:
        raise TelnyxSerializerError("telnyx_serializer_invalid")
    return parsed


def _require_mapping(value: object) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise TelnyxSerializerError("telnyx_serializer_invalid")
    return value


def _dtmf_metadata(message: dict[str, Any]) -> tuple[datetime | None, int | None]:
    """Project bounds qualify timing; unknown timing preserves ordinary keypad input."""
    timestamp = message.get("occurred_at")
    sequence = message.get("sequence_number")
    if not isinstance(timestamp, str) or not isinstance(sequence, str):
        return None, None
    if (
        not 1 <= len(sequence) <= MAX_DTMF_SEQUENCE_DIGITS
        or not sequence.isascii() or not sequence.isdecimal()
        or len(sequence) > 1 and sequence[0] == "0"
    ):
        return None, None
    try:
        if len(timestamp.encode("utf-8")) > MAX_DTMF_TIMESTAMP_BYTES:
            return None, None
    except UnicodeEncodeError:
        return None, None
    if _DTMF_UTC_TIMESTAMP.fullmatch(timestamp) is None:
        return None, None
    number = int(sequence)
    if number > MAX_DTMF_SEQUENCE:
        return None, None
    try:
        occurred_at = datetime.fromisoformat(timestamp)
    except ValueError:
        return None, None
    return occurred_at, number


class ProjetV0TelnyxFrameSerializer(TelnyxFrameSerializer):
    """Validate inbound media and bounded native Telnyx extension messages."""

    def __init__(
        self,
        stream_id: str,
        *,
        expected_call_control_id: str,
        audio_admission: AudioAdmission | None = None,
    ) -> None:
        authenticated_stream_id = bounded_utf8_text(
            stream_id,
            maximum_bytes=MAX_STREAM_ID_BYTES,
        )
        self._expected_call_control_id = bounded_utf8_text(
            expected_call_control_id,
            maximum_bytes=MAX_CALL_CONTROL_ID_BYTES,
        )
        self.audio_admission = audio_admission or AudioAdmission()
        params = TelnyxFrameSerializer.InputParams(
            telnyx_sample_rate=8000,
            outbound_encoding="PCMU",
            inbound_encoding="PCMU",
            auto_hang_up=False,
        )
        super().__init__(
            stream_id=authenticated_stream_id,
            outbound_encoding="PCMU",
            inbound_encoding="PCMU",
            params=params,
        )

    async def serialize(self, frame: Frame) -> str | bytes | None:
        if isinstance(frame, TelnyxMarkFrame):
            mark_name = bounded_utf8_text(
                frame.mark_name,
                maximum_bytes=MAX_MARK_NAME_BYTES,
            )
            return json.dumps(
                {"event": "mark", "mark": {"name": mark_name}},
                ensure_ascii=False,
                separators=(",", ":"),
            )
        # Native 1.12 forwards generic messages; only our validated mark owns
        # this project's outbound extension authority.
        if isinstance(frame, (OutputTransportMessageFrame, OutputTransportMessageUrgentFrame)):
            return None
        return await super().serialize(frame)

    async def deserialize(self, data: str | bytes) -> Frame | None:
        initial = _require_mapping(
            _load_json(
                data,
                maximum_bytes=MAX_WEBSOCKET_MESSAGE_BYTES,
                object_pairs_hook=_unique_object,
            )
        )
        if initial.get("event") == "media":
            stream_id = bounded_utf8_text(
                initial.get("stream_id"), maximum_bytes=MAX_STREAM_ID_BYTES
            )
            if stream_id != self._stream_id:
                raise TelnyxSerializerError("telnyx_serializer_invalid")
            media = _require_mapping(initial.get("media"))
            track = media.get("track")
            payload = media.get("payload")
            if (
                track not in ("inbound", "outbound")
                or not isinstance(payload, str)
                or not payload
            ):
                raise TelnyxSerializerError("telnyx_serializer_invalid")
            if track == "outbound":
                return None
            try:
                allowed = self.audio_admission.allows_audio()
            except AudioAdmissionError:
                raise TelnyxSerializerError("telnyx_audio_admission_failed") from None
            if not allowed:
                return None

        if initial.get("event") == "dtmf":
            stream_id = bounded_utf8_text(
                initial.get("stream_id"), maximum_bytes=MAX_STREAM_ID_BYTES
            )
            if stream_id != self._stream_id:
                raise TelnyxSerializerError("telnyx_serializer_invalid")

        if initial.get("event") not in {
            "mark",
            "stop",
            "error",
        }:
            frame = await super().deserialize(data)
            if initial.get("event") == "dtmf" and isinstance(frame, InputDTMFFrame):
                occurred_at, sequence_number = _dtmf_metadata(initial)
                return TelnyxInputDTMFFrame(
                    button=frame.button, occurred_at=occurred_at, sequence_number=sequence_number
                )
            if isinstance(frame, InputAudioRawFrame):
                try:
                    return frame if self.audio_admission.allows_audio() else None
                except AudioAdmissionError:
                    raise TelnyxSerializerError("telnyx_audio_admission_failed") from None
            return frame

        message = _require_mapping(
            _load_json(
                data,
                maximum_bytes=MAX_EXTENSION_MESSAGE_BYTES,
                object_pairs_hook=_unique_object,
            )
        )
        event = message.get("event")
        stream_id = bounded_utf8_text(
            message.get("stream_id"),
            maximum_bytes=MAX_STREAM_ID_BYTES,
        )
        if stream_id != self._stream_id:
            raise TelnyxSerializerError("telnyx_serializer_invalid")

        if event == "mark":
            mark = _require_mapping(message.get("mark"))
            name = bounded_utf8_text(mark.get("name"), maximum_bytes=MAX_MARK_NAME_BYTES)
            return InputTransportMessageFrame(
                message={"event": "mark", "mark": {"name": name}}
            )
        if event == "stop":
            stop = _require_mapping(message.get("stop"))
            call_control_id = bounded_utf8_text(
                stop.get("call_control_id"),
                maximum_bytes=MAX_CALL_CONTROL_ID_BYTES,
            )
            if not hmac.compare_digest(
                call_control_id.encode("utf-8"),
                self._expected_call_control_id.encode("utf-8"),
            ):
                raise TelnyxSerializerError("telnyx_serializer_invalid")
            return InputTransportMessageFrame(message={"event": "stop"})
        if event == "error":
            payload = _require_mapping(message.get("payload"))
            code = payload.get("code")
            if type(code) is not int or not 0 <= code <= MAX_ERROR_CODE:
                raise TelnyxSerializerError("telnyx_serializer_invalid")
            title = bounded_utf8_text(
                payload.get("title"),
                maximum_bytes=MAX_ERROR_FIELD_BYTES,
            )
            return InputTransportMessageFrame(
                message={"event": "error", "payload": {"code": code, "title": title}}
            )
        raise TelnyxSerializerError("telnyx_serializer_invalid")


__all__ = [
    "AudioAdmission",
    "AudioAdmissionError",
    "ProjetV0TelnyxFrameSerializer",
    "TelnyxSerializerError",
]
